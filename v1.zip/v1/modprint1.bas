Attribute VB_Name = "modprint1"
 
Sub SaveAsWB()
Sheets("LOGSHEET").Activate
If Sheets("LOGSHEET").Range("H61") = "" Then
 Exit Sub
Dim fName As String
With Worksheets("LOGSHEET")
    'fName = .Range("Z2").Value & .Range("Z3").Value
    fName = .Range("H61").Value
.Copy
    ActiveWorkbook.SaveAs "E:\SP\" & fName & ".xlsm", FileFormat:=xlOpenXMLWorkbookMacroEnabled, CreateBackup:=False
    ActiveWindow.Close

End With
End If
End Sub

 
Sub SaveAsPDF()
 Sheets("LOGSHEET").Activate
 If Sheets("LOGSHEET").Range("H61") = "" Then
 Exit Sub
 Else
Dim fName As String
With Worksheets("LOGSHEET")
    
    fName = .Range("H61").Value
    
End With

Sheets("LOGSHEET").Range("A1:AB32").ExportAsFixedFormat Type:=xlTypePDF, Filename:="E:\SP\PDF\" & fName, Quality:=xlQualityStandard, _
            IncludeDocProperties:=True, IgnorePrintAreas:=False, OpenAfterPublish:=False
 End If
End Sub

Sub MakeFoderCopy()
Sheets("LOGSHEET").Activate
Application.DisplayAlerts = False
If Sheets("LOGSHEET").Range("H61") = "" Then
 Exit Sub
 Else
Dim strFilename, strDirname, strPathname, strDefpath As String

 On Error Resume Next ' If directory exist goto next line
 With Worksheets("LOGSHEET")
    strFilename = .Range("H61").Value  'New file name

strDirname = Range("H62").Value ' New directory name

'strFilename = Range("Z2").Value 'New file name
strDefpath = "E:\SP\EXCEL\" 'Application.ActiveWorkbook.Path 'Default path name
If IsEmpty(strDirname) Then Exit Sub
If IsEmpty(strFilename) Then Exit Sub
MkDir strDefpath & strDirname
strPathname = strDefpath & strDirname & "\" & strFilename 'create total string


'MkDir strDefpath & "\" & strDirname
'strPathname = strDefpath & "\" & strDirname & "\" & strFilename 'create total string
.Copy
ActiveWorkbook.SaveAs Filename:=strPathname & ".xlsx", _
FileFormat:=xlOpenXMLWorkbook, Password:="", WriteResPassword:="", _
ReadOnlyRecommended:=False, CreateBackup:=False
ActiveWorkbook.Close
End With
End If
Application.DisplayAlerts = True
End Sub
Sub swi()
  ' Dim NewPath As String
   'NewPath = "C:\TestFolder\Swi"
  ' MkDir NewPath
   'ActiveWorkbook.SaveAs FileName:=NewPath & "\" & "whatever.xlsm", FileFormat:=xlOpenXMLWorkbookMacroEnabled
End Sub


Function PrintRange()
rspn = MsgBox("Do Want To Print Logsheet?", vbYesNo)
If rspn = vbNo Then Exit Function
Sheets("LOGSHEET").Activate

     Range("A1:AB32").printOut
End Function


Public Sub SaveAsPDF_1()

    On Error GoTo ErrHandler
    
    Dim ws As Worksheet
    Dim fName As String
    Dim folderPath As String
    Dim filePath As String
    
    Set ws = Sheets("LOGSHEET")
    
    ' Get file name
    fName = Trim(ws.Range("H61").Value)
    If fName = "" Then Exit Sub
    
    ' Folder path (Workbook folder + PDF)
    folderPath = ThisWorkbook.Path & "\PDF"
    
    ' Create folder if missing
    If Dir(folderPath, vbDirectory) = "" Then
        MkDir folderPath
    End If
    
    ' Final file path
    filePath = folderPath & "\" & fName & ".pdf"
    
    ' Export PDF
    ws.Range("A1:AB32").ExportAsFixedFormat _
        Type:=xlTypePDF, _
        Filename:=filePath, _
        Quality:=xlQualityStandard, _
        IncludeDocProperties:=True, _
        IgnorePrintAreas:=False, _
        OpenAfterPublish:=False

    Exit Sub

ErrHandler:
    MsgBox "PDF Save Failed!" & vbCrLf & _
           "Error: " & Err.Description, _
           vbCritical, "PDF ERROR"

End Sub

Sub MakeFoderCopy_1()
Sheets("LOGSHEET").Activate
Application.DisplayAlerts = False
If Sheets("LOGSHEET").Range("H61") = "" Then
 Exit Sub
 Else
Dim strFilename, strDirname, strPathname, strDefpath As String

 On Error Resume Next ' If directory exist goto next line
 With Worksheets("LOGSHEET")
    strFilename = .Range("H61").Value  'New file name

strDirname = Range("H62").Value ' New directory name

'strFilename = Range("Z2").Value 'New file name
strDefpath = "E:\SP\EXCEL\" 'Application.ActiveWorkbook.Path 'Default path name
If IsEmpty(strDirname) Then Exit Sub
If IsEmpty(strFilename) Then Exit Sub
MkDir strDefpath & strDirname
strPathname = strDefpath & strDirname & "\" & strFilename 'create total string


'MkDir strDefpath & "\" & strDirname
'strPathname = strDefpath & "\" & strDirname & "\" & strFilename 'create total string
.Copy
ActiveWorkbook.SaveAs Filename:=strPathname & ".xlsx", _
FileFormat:=xlOpenXMLWorkbook, Password:="", WriteResPassword:="", _
ReadOnlyRecommended:=False, CreateBackup:=False
ActiveWorkbook.Close
End With
End If
Application.DisplayAlerts = True
End Sub

