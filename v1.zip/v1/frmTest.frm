VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmTest 
   Caption         =   "UserForm1"
   ClientHeight    =   2430
   ClientLeft      =   30
   ClientTop       =   420
   ClientWidth     =   3780
   OleObjectBlob   =   "frmTest.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Option Explicit

Private Sub CommandButton1_Click()
    Unload Me
End Sub

Private Sub CommandButton2_Click()
frmCalendar.Show_Cal
End Sub

Private Sub TextBox1_Enter()
    g_bForm = True
    frmCalendar.Show_Cal
    Me.TextBox1.Value = g_sDate
End Sub

