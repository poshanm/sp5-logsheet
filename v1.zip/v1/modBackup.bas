Attribute VB_Name = "modBackup"
Public Function GetBackupPath() As String

    Dim basePath As String
    Dim yearPath As String
    Dim monthPath As String
    
    basePath = ThisWorkbook.Path & "\Backup"
    yearPath = basePath & "\" & Year(Date)
    monthPath = yearPath & "\" & Format(Date, "mmmm")
    
    If Dir(basePath, vbDirectory) = "" Then MkDir basePath
    If Dir(yearPath, vbDirectory) = "" Then MkDir yearPath
    If Dir(monthPath, vbDirectory) = "" Then MkDir monthPath
    
    GetBackupPath = monthPath

End Function


Public Sub CreateShiftBackup()

    Dim backupPath As String
    backupPath = GetBackupPath()
    
    Dim fileName As String
    fileName = "Backup_" & _
               Sheets("DAILY").Range("S4").Value & "_" & _
               Sheets("DAILY").Range("T3").Value & ".xlsm"
    
    ThisWorkbook.SaveCopyAs backupPath & "\" & fileName

End Sub

