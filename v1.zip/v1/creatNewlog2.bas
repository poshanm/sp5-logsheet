Attribute VB_Name = "creatNewlog2"

Sub CreatNewLog1()
'
' CreatNewLog() Macro
'

'
Dim msg1 As String
Dim msg2 As String
 msg1 = Sheets("timesheet").Range("D86").Text
 msg2 = Sheets("timesheet").Range("D87").Text
rspn = MsgBox(msg1, vbYesNoCancel)
If rspn = vbNo Then Exit Sub
If rspn = vbYes Then

rsp = MsgBox(msg2, vbOKCancel)
If rsp = vbOK Then
Call UnProtect
 Application.EnableEvents = False


'Call SaveAsWB
'Call SaveAsPDF
      Dim ws As Worksheet
      Set ws = Worksheets("LOGSHEET")
      Sheets("LOGSHEET").Activate
    If Range("H56").Value = "TRUE" Then
      'Call record
      Call MakeFoderCopy
     ' Call SaveAsPDF
    Call Date1Reset
    Call ClData
    Call clear_timesheet1
 
    NewLogsheet.Show
    NewLogsheet1.Show
  ElseIf Range("H56").Value = "FALSE" Then
    
    Call MakeFoderCopy
   ' Call SaveAsPDF
    Call CopyPrevR
    Call ClData
    Call clear_timesheet1
    NewLogsheet.Show
    NewLogsheet1.Show
    Application.EnableEvents = False
    Call Protect
    
  End If
  End If
  End If
  
End Sub
