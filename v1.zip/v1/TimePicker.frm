VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} TimePicker 
   Caption         =   "Time Picker"
   ClientHeight    =   2415
   ClientLeft      =   105
   ClientTop       =   450
   ClientWidth     =   5760
   OleObjectBlob   =   "TimePicker.frx":0000
   ShowModal       =   0   'False
   StartUpPosition =   2  'CenterScreen
End
Attribute VB_Name = "TimePicker"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Option Explicit

Private Sub CommandButton1_Click()

    Selection.Value = Me.txt_hours & ":" & Me.txt_Min & ":" & 0 & " " & Me.txt_AM_PM
    Me.Hide
    
End Sub

Private Sub CommandButton2_Click()
Me.Hide
End Sub







Private Sub SpinButton1_Change()
    
    If Me.SpinButton1.Value = 0 Then Me.SpinButton1.Value = 12
    If Me.SpinButton1.Value = 13 Then Me.SpinButton1.Value = 1
    
    Me.txt_hours.Value = Format(Me.SpinButton1.Value, "00")
    
End Sub

Private Sub SpinButton2_Change()
    If Me.SpinButton2.Value = -1 Then Me.SpinButton2.Value = 59
    If Me.SpinButton2.Value = 60 Then Me.SpinButton2.Value = 0
    Me.txt_Min.Value = Format(Me.SpinButton2.Value, "00")
End Sub

Private Sub SpinButton3_Change()
    
    If Me.SpinButton3.Value = -1 Then Me.SpinButton3.Value = 59
    If Me.SpinButton3.Value = 60 Then Me.SpinButton3.Value = 0
    
    Me.txt_Min.Value = Format(Me.SpinButton2.Value, "00")
    
    Me.txt_Sec.Value = Format(Me.SpinButton3.Value, "00")
End Sub

Private Sub SpinButton4_Change()

    If Me.SpinButton4.Value = 0 Then Me.SpinButton4.Value = 2
    If Me.SpinButton4.Value = 3 Then Me.SpinButton4.Value = 1
    
    Me.txt_AM_PM.Value = IIf(Me.SpinButton4.Value = 1, "AM", "PM")
End Sub





Private Sub UserForm_Activate()



 

    Me.txt_hours.Value = Left(Format(Time, "HH AM/PM"), 2)
    Me.SpinButton1.Value = Me.txt_hours.Value

    Me.txt_Min.Value = Round(Format(Minute(Time), "00"), 2)
    Me.SpinButton2.Value = Me.txt_Min.Value
    Me.txt_Sec.Value = Format(Time, "SS")
     Me.SpinButton3.Value = Me.txt_Sec.Value

    Me.txt_AM_PM.Value = Format(Time, "AM/PM")

End Sub

 

 

 
