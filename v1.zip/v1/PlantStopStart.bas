Attribute VB_Name = "PlantStopStart"
Option Explicit

Private Sub Copy2Cells(srcRange As String, destRange As String)


Dim ws As Worksheet
Set ws = Sheets("TIMESHEET")

ws.Range(destRange).Value = ws.Range(srcRange).Value


End Sub

'========================
' PLANT START
'========================

Sub PlantSt1()
Copy2Cells "F56:G56", "L2:M2"
End Sub

Sub PlantSt2()
Copy2Cells "F57:G57", "P2:Q2"
End Sub

Sub PlantSt3()
Copy2Cells "F58:G58", "S2:T2"
End Sub

Sub PlantSt4()
Copy2Cells "F59:G59", "W2:X2"
End Sub

'========================
' PLANT STOP
'========================

Sub PlantSp1()
Copy2Cells "F60:G60", "L3:M3"
End Sub

Sub PlantSp2()
Copy2Cells "F61:G61", "P3:Q3"
End Sub

Sub PlantSp3()
Copy2Cells "F62:G62", "S3:T3"
End Sub

Sub PlantSp4()
Copy2Cells "F63:G63", "W3:X3"
End Sub

