VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} LanguageOption 
   Caption         =   " Language Option"
   ClientHeight    =   2580
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   3885
   OleObjectBlob   =   "LanguageOption.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "LanguageOption"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub CommandButton1_Click()
Unload Me
End Sub

Private Sub OptionButton1_Click()
If OptionButton1.Value = True Then
Sheets("timesheet").Range("C50").Value = "H"
Else
Sheets("timesheet").Range("C50").Value = ""
End If
End Sub

Private Sub OptionButton2_Click()
If OptionButton2.Value = True Then
Sheets("timesheet").Range("C50").Value = "E"
Else
Sheets("timesheet").Range("C50").Value = ""
End If
End Sub

