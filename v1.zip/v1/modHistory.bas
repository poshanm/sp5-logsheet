Attribute VB_Name = "modHistory"
Public Sub SaveShiftToHistory()

    Dim wsH As Worksheet
    Set wsH = Sheets("PRO_HISTORY")
    
    Dim nextRow As Long
    nextRow = wsH.Cells(wsH.Rows.Count, 1).End(xlUp).Row + 1
    
    wsH.Cells(nextRow, 1).Value = Sheets("DAILY").Range("S4").Value
    wsH.Cells(nextRow, 2).Value = Sheets("DAILY").Range("T3").Value
    
    wsH.Cells(nextRow, 3).Value = Sheets("LOGSHEET").Range("H17").Value
    
    wsH.Cells(nextRow, 10).Value = Sheets("TIMESHEET").Range("AA7").Value
    
    wsH.Cells(nextRow, 11).Value = _
        (Sheets("TIMESHEET").Range("AG8").Value / 480) * 100
    
    wsH.Cells(nextRow, 12).Value = Now

End Sub

