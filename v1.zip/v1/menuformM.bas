Attribute VB_Name = "menuformM"
Sub menu()


MenuForm.Show
End Sub
Public Sub opencalender()
Call Datepicker
'NewLogsheet.Show


    frmCalendar.Show_Cal
    
End Sub
