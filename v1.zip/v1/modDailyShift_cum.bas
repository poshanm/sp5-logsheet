Attribute VB_Name = "modDailyShift_cum"
Public Sub SHIFT1()

    Dim ws As Worksheet
    Set ws = Sheets("DAILY")
    
    ws.Range("I28:I34").Value = ws.Range("I37:I43").Value

End Sub


Public Sub SHIFT2()

    Dim ws As Worksheet
    Set ws = Sheets("DAILY")
    
    ws.Range("J28:J34").Value = ws.Range("J37:J43").Value

End Sub


Public Sub SHIFT3()

    Dim ws As Worksheet
    Set ws = Sheets("DAILY")
    
    ws.Range("K28:K34").Value = ws.Range("K37:K43").Value

End Sub
 Public Sub Shift_cum()

    Dim wsD As Worksheet
    Dim wsL As Worksheet
    Dim shiftName As String
    
    Set wsD = Sheets("DAILY")
    Set wsL = Sheets("DAILY")
    
    shiftName = wsD.Range("T3").Value
    
    ' ?? If new date, move previous day data
    If wsD.Range("T4").Value <> Date Then
        
        PRE_DAY
        
        ' Copy M19:M25 ? H28:H34
        wsL.Range("H28:H34").Value = wsD.Range("M19:M25").Value
        
        ' Clear cumulative area
        wsL.Range("I28:K34").ClearContents
        
    End If
    
    ' ?? Shift cumulative update
    Select Case shiftName
        Case "1st": SHIFT1
        Case "2nd": SHIFT2
       ' Case "3rd": SHIFT3
    End Select

End Sub
 
Public Sub PRE_DAY()

    Dim wsD As Worksheet
    Dim wsL As Worksheet
    
    Set wsD = Sheets("DAILY")
    Set wsL = Sheets("DAILY")
    
    ' Clear previous area
    wsL.Range("M27").ClearContents
    wsL.Range("O28:T34").ClearContents
    
    ' Copy Date (T4 ? M27)
    wsL.Range("M27").Value = wsD.Range("T4").Value
    
    ' Copy production blocks
    wsL.Range("O28:Q34").Value = wsD.Range("I19:K25").Value
    wsL.Range("S28:S34").Value = wsD.Range("L19:L25").Value
    wsL.Range("T28:T34").Value = wsD.Range("M19:M25").Value

End Sub

