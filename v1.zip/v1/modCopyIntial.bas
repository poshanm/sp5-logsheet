Attribute VB_Name = "modCopyIntial"
Public Sub Date1Reset()

    Dim ws As Worksheet
    Set ws = Sheets("LOGSHEET")
    
    ws.Range("D15:AA15").ClearContents
    ws.Range("X21:X24").ClearContents
    ws.Range("X26").ClearContents
    ws.Range("X28").ClearContents
    ws.Range("X30").ClearContents
    ws.Range("Q21").ClearContents
    ws.Range("Q25").ClearContents

End Sub
Public Sub CopyPrevR()

    Dim ws As Worksheet
    Set ws = Sheets("LOGSHEET")
    
    ws.Range("Q25:Q31").Value = ws.Range("T25:T31").Value
    ws.Range("Q21").Value = ws.Range("T21").Value
    
    ws.Range("X21:X24").Value = ws.Range("AA21:AA24").Value
    ws.Range("X26").Value = ws.Range("AA26").Value
    ws.Range("X28").Value = ws.Range("AA28").Value
    ws.Range("X30").Value = ws.Range("AA30").Value
    
    ws.Range("D15:AA15").Value = ws.Range("D17:AA17").Value

End Sub
Public Sub CopyInitial()

    Dim wsD As Worksheet
    Dim wsL As Worksheet
    
    Set wsD = Sheets("DAILY")
    Set wsL = Sheets("LOGSHEET")
    
    wsD.Range("D5:P5").Value = wsL.Range("D17:P17").Value

End Sub

Public Sub CopyInitial2()

    Dim wsD As Worksheet
    Set wsD = Sheets("DAILY")
    
    wsD.Range("D5:E5").Value = wsD.Range("D40:E40").Value
    wsD.Range("F5:G5").Value = wsD.Range("F40:G40").Value
    wsD.Range("H5:I5").Value = wsD.Range("H40:I40").Value

End Sub

