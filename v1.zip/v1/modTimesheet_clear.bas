Attribute VB_Name = "modTimesheet_clear"
Sub clear_timesheet()
'
' clear_timesheet Macro
'

'
   Dim msg1 As String
 msg1 = Sheets("timesheet").Range("D85").Text
   rspn = MsgBox(msg1, vbYesNo)
If rspn = vbNo Then Exit Sub
Sheets("timesheet").Select
    Range( _
        "B7:C17,E7:F17,H7:I17,K7:L17,N7:O17,Q7:R17,T7:U17,W7:X17,B21:C31,E21:I31,K21:L31,N21:R31"). _
        Select
    
    Selection.ClearContents
    Range("T20").Select
End Sub
Sub clear_timesheet1()
'
' clear_timesheet crear new log and clear data Macro
'

'
  
Sheets("timesheet").Select
    Range( _
        "B7:C17,E7:F17,H7:I17,K7:L17,N7:O17,Q7:R17,T7:U17,W7:X17,B21:C31,E21:I31,K21:L31,N21:R31"). _
        Select
    
    Selection.ClearContents
    Range("T20").Select
End Sub



