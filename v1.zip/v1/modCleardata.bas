Attribute VB_Name = "modCleardata"
Public Sub ClearTimesheet()

    Dim ws As Worksheet
    Dim msgText As String
    
    Set ws = Sheets("TIMESHEET")
    
    msgText = ws.Range("D85").Value
    
    If MsgBox(msgText, vbYesNo + vbQuestion) = vbNo Then Exit Sub
    
    ws.Range("B7:C17,E7:F17,H7:I17,K7:L17," & _
             "N7:O17,Q7:R17,T7:U17,W7:X17," & _
             "B21:C31,E21:I31,K21:L31,N21:R31").ClearContents

End Sub

Public Sub clear_timesheet1()

    Dim ws As Worksheet
    Set ws = Sheets("TIMESHEET")
    
    ws.Range("B7:C17,E7:F17,H7:I17,K7:L17," & _
             "N7:O17,Q7:R17,T7:U17,W7:X17," & _
             "B21:C31,E21:I31,K21:L31,N21:R31").ClearContents

End Sub

Public Sub ClData()

    With Sheets("DAILY")
        .Range("D7:P14,T3:T4,U7:U15").ClearContents
    End With

End Sub
Public Sub CLEAR_STOPPAGE()

    With Sheets("DAILY")
        .Range("P20:R22").ClearContents
    End With

End Sub

Public Sub ClearStSp()

    With Sheets("LOGSHEET")
        .Range("M2:N3,Q2:R3,T2:U3,X2:Y3").ClearContents
    End With

End Sub




