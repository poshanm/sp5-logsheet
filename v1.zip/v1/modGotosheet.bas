Attribute VB_Name = "modGotosheet"

' ==== DATE PICKER ====
Public Sub Datepicker()
    Sheets("DAILY").Activate
    Sheets("DAILY").Range("T4").Select
End Sub
' ==== GO TO DAILY ====
Public Sub GoToDaily()
    Sheets("DAILY").Activate
End Sub
' ==== GO TO LOGSHEET ====
Public Sub GoToLogsheet()
    Sheets("LOGSHEET").Activate
End Sub
' ==== SUBMIT (SAVE PROPERLY) ====
Public Sub SubmitData()
    
    ThisWorkbook.Save   ' ?? No SendKeys nonsense
    Sheets("DAILY").Range("B16").Select
    
End Sub
' ==== GO TO TIMESHEET ====
Public Sub GoToTimesheet()
    Sheets("TIMESHEET").Activate
End Sub

' ==== OPEN CALENDAR ====
Public Sub OpenCalendar()

    Sheets("DAILY").Activate
    Sheets("DAILY").Range("T4").Select
    
    frmCalendar.Show

End Sub
Sub Datepicker_1()
'
' Datepicker Macro
'

'Sheets("DAILY").Activate
    Sheets("DAILY").Range("T4").Select
End Sub

