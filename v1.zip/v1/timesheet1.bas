Attribute VB_Name = "timesheet1"
Option Explicit

Private Sub CopyLastValue(srcCol As String, srcStartRow As Long, destCol As String, destStartRow As Long)

    Dim ws As Worksheet
    Dim lastSrc As Long
    Dim lastDest As Long
    
    Set ws = Sheets("TIMESHEET")
    
    lastSrc = ws.Cells(ws.Rows.Count, srcCol).End(xlUp).Row
    If lastSrc < srcStartRow Then Exit Sub
    
    lastDest = ws.Cells(ws.Rows.Count, destCol).End(xlUp).Row
    If lastDest < destStartRow Then lastDest = destStartRow - 1
    
    ws.Cells(lastDest + 1, destCol).Value = ws.Cells(lastSrc, srcCol).Value

End Sub


Sub LPSTOP()
CopyLastValue "C", 5, "K", 19
End Sub

Sub SPSTOP()
CopyLastValue "C", 5, "B", 19
End Sub

Sub ALINE()
CopyLastValue "C", 19, "E", 5
End Sub

Sub ALINE1()
CopyLastValue "L", 19, "E", 5
End Sub

Sub BLINE()
CopyLastValue "C", 19, "H", 5
End Sub

Sub BLINE1()
CopyLastValue "L", 19, "H", 5
End Sub

Sub CLINE()
CopyLastValue "C", 19, "K", 5
End Sub

Sub CLINE1()
CopyLastValue "L", 19, "K", 5
End Sub

Sub DLINE()
CopyLastValue "C", 19, "N", 5
End Sub

Sub DLINE1()
CopyLastValue "L", 19, "N", 5
End Sub

Sub TCPA()
CopyLastValue "C", 19, "Q", 5
End Sub

Sub TCPA1()
CopyLastValue "L", 19, "Q", 5
End Sub

Sub TCPB()
CopyLastValue "C", 19, "T", 5
End Sub

Sub TCPB1()
CopyLastValue "L", 19, "T", 5
End Sub

Sub TCPC()
CopyLastValue "C", 19, "W", 5
End Sub

Sub TCPC1()
CopyLastValue "L", 19, "W", 5
End Sub

Sub LTOS()
CopyLastValue "C", 19, "K", 19
End Sub

Sub STOL()
CopyLastValue "L", 19, "B", 19
End Sub

Sub LTOCO()
CopyLastValue "C", 19, "B", 5
End Sub

Sub STOCO()
CopyLastValue "L", 19, "B", 5
End Sub
