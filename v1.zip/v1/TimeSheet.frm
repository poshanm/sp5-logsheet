VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} TimeSheet 
   Caption         =   "TIME SHEET ENTRY"
   ClientHeight    =   4155
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   9015.001
   OleObjectBlob   =   "TimeSheet.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "TimeSheet"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub Closebutton_Click()
ComboBox6.Value = " "
ComboBox5.Value = " "
ComboBox4.Value = " "
ComboBox3.Value = " "
ComboBox2.Value = " "
ComboBox1.Value = " "

Unload Me

End Sub

Private Sub ComboBox1_Change()
ComboBox1.Value = Format(ComboBox1, "h:mm AM/PM")
ComboBox1.Value = IIf(ComboBox1.Value = "12:25 AM" Or ComboBox1.Value = "1:25 AM", "06:00 ", ComboBox1)
 ComboBox1.Value = IIf(ComboBox1.Value = "12:05 AM" Or ComboBox1.Value = "1:05 AM", "12:00 ", ComboBox1)

End Sub

Private Sub ComboBox2_Change()
ComboBox2.Value = Format(ComboBox2, "h:mm")
End Sub



Private Sub ComboBox3_Change()
Range("CV6").Value = ComboBox3.Text
End Sub

Private Sub ComboBox4_Change()
ComboBox4.Value = Format(ComboBox4, "h:mm")
End Sub



Private Sub ComboBox5_Change()
ComboBox5.Value = Format(ComboBox5, "h:mm AM/PM")

 ComboBox5.Value = IIf(ComboBox5.Value = "12:25 AM" Or ComboBox5.Value = "1:25 AM", "06:00 ", ComboBox5)
 ComboBox5.Value = IIf(ComboBox5.Value = "12:05 AM" Or ComboBox5.Value = "1:05 AM", "12:00 ", ComboBox5)

End Sub


Private Sub ComboBox6_Change()

Range("CR6").Value = ComboBox6.Text
End Sub

'Private Sub ComboBox6_AfterUpdate()
'If ComboBox6 = "A LINE START" Then
' Me.ComboBox5.RowSource = TimeSheet.hourminAst
'Else
' Me.ComboBox5.RowSource = "timesheet!hour"
'End If
'End Sub






Private Sub ResetButton3_Click()
ComboBox6.Value = ""
ComboBox5.Value = ""
ComboBox4.Value = ""
ComboBox3.Value = ""
ComboBox2.Value = ""
ComboBox1.Value = ""

Range("AU6").Value = ""
Range("AW6").Value = ""
Range("AU5").Value = ""
Range("AV5").Value = ""
Range("AX5").Value = ""
Range("AW5").Value = ""
Range("CR6").Value = ""
Range("CV6").Value = ""
End Sub
Function validate() As Boolean

   ' Dim ret As Boolean
   ' If Not IsNull(ComboBox6.Value) _
   '  And (ComboBox5.Value) = "" Then
   ' ret = False
   ' End If
    'If Not IsNull(ComboBox3.Value) _
   ' And (ComboBox1.Value) = "" Then
   '   ret = True
   ' End If
    
    

    'End If

    'validate = ret

End Function

Private Sub SaveButton1_Click()
Dim msg1 As String
Dim msg2 As String
 msg1 = Sheets("timesheet").Range("D82").Text
 msg1 = Sheets("timesheet").Range("D83").Text
'If ComboBox1.ListIndex > -1
  
'check for a MINUT EMPTY number

'If Not IsNull(ComboBox6.Value) And (ComboBox5.Value) = "" Then
 ' Me.ComboBox1.SetFocus
  'Me.ComboBox5.SetFocus
 'MsgBox "Please enter  minut time "
  'Exit Sub
'End If
'Set ws = Worksheets("timesheet")
'If Not IsNull(ComboBox3.Value) And (ComboBox1.Value) = "" Then
 ' Me.ComboBox1.SetFocus
 'MsgBox "Please enter  minut time "
 ' Exit Sub
'End If

' If Not validate() Then
  '   MsgBox "Fill all required fields, please"
   '  Else
   '  MsgBox "Fill all required fields, please2"
   '  Cancel = True
  '  End If
  Dim iReply As Integer
Dim vComboEntry As Variant
    If (ComboBox6.ListIndex) > -1 And (ComboBox5.Value) = "" And Range("AU5").Value = "" Then
        'iReply = MsgBox("Your START time entry is Empty " _
                    & "Do you wish to add it", vbYesNo)
        iReply = MsgBox(msg1, vbYesNo)
        Select Case iReply
            Case vbNo
            Exit Sub
                '<carry on code>
            Case vbYes
                
                ComboBox5.SetFocus
                Exit Sub
        End Select
        Else
        If (ComboBox6.Value) <> "" And (ComboBox5.Value) <> "" Then
        Range("AU5").Value = ComboBox5.Text
    End If
    End If
 Dim jReply As Integer
Dim yComboEntry As Variant
    If (ComboBox3.ListIndex) > -1 And (ComboBox1.Value) = "" And Range("AW5").Value = "" Then
        jReply = MsgBox(msg2, vbYesNo)

        Select Case jReply
            Case vbNo
            Exit Sub
                '<carry on code>
            Case vbYes
                
                ComboBox1.SetFocus
                Exit Sub
        End Select
        Else
        If (ComboBox3.Value) <> "" And (ComboBox1.Value) <> "" Then
        Range("AW5").Value = ComboBox1.Text
    End If
    End If

Range("AU6").Value = ComboBox6.Text
Range("AW6").Value = ComboBox3.Text
'Range("AU5").Value = ComboBox5.Text
Range("AV5").Value = ComboBox4.Text
'Range("AW5").Value = ComboBox1.Text
Range("AX5").Value = ComboBox2.Text
 

ComboBox6.Value = ""
ComboBox5.Value = ""
ComboBox4.Value = ""
ComboBox3.Value = ""
ComboBox2.Value = ""
ComboBox1.Value = ""
Range("AU6").Value = ""
Range("AW6").Value = ""
Range("AU5").Value = ""
Range("AV5").Value = ""
Range("AX5").Value = ""
Range("AW5").Value = ""
Range("CR6").Value = ""
Range("CV6").Value = ""


End Sub




Private Sub UserForm_Initialize()
Range("AQ17").Value = "1"
Sheets("timesheet").Activate

End Sub


Private Sub UserForm_Terminate()
Range("AQ17").Value = "0"
End Sub
