Attribute VB_Name = "timesheet3"
Option Explicit

Private Sub CopyLast(srcCol As String, srcStartRow As Long, destCol As String, destStartRow As Long)

    Dim ws As Worksheet
    Dim lastSrc As Long
    Dim lastDest As Long
    
    Set ws = Sheets("TIMESHEET")
    
    lastSrc = ws.Cells(ws.Rows.Count, srcCol).End(xlUp).Row
    If lastSrc < srcStartRow Then Exit Sub
    
    lastDest = ws.Cells(ws.Rows.Count, destCol).End(xlUp).Row
    If lastDest < destStartRow Then lastDest = destStartRow - 1
    
    ws.Cells(lastDest + 1, destCol).Value = ws.Cells(lastSrc, srcCol).Value

End Sub


'========================
' START WITH FORM
'========================

Sub CL_START_WITH_FORM()
CopyLast "AY", 3, "B", 5
End Sub

Sub A_START_WITH_FORM()
CopyLast "AY", 3, "E", 5
End Sub

Sub B_START_WITH_FORM()
CopyLast "AY", 3, "H", 5
End Sub

Sub C_START_WITH_FORM()
CopyLast "AY", 3, "K", 5
End Sub

Sub D_START_WITH_FORM()
CopyLast "AY", 3, "N", 5
End Sub

Sub TCPA_START_WITH_FORM()
CopyLast "AY", 3, "Q", 5
End Sub

Sub TCPB_START_WITH_FORM()
CopyLast "AY", 3, "T", 5
End Sub

Sub TCPC_START_WITH_FORM()
CopyLast "AY", 3, "W", 5
End Sub

Sub LP_START_WITH_FORM()
CopyLast "AY", 3, "K", 19
End Sub

Sub SP_START_WITH_FORM()
CopyLast "AY", 3, "B", 19
End Sub


'========================
' STOP WITH FORM
'========================

Sub CL_STOP_WITH_FORM()
CopyLast "AZ", 3, "C", 5
End Sub

Sub A_STOP_WITH_FORM()
CopyLast "AZ", 3, "F", 5
End Sub

Sub B_STOP_WITH_FORM()
CopyLast "AZ", 3, "I", 5
End Sub

Sub C_STOP_WITH_FORM()
CopyLast "AZ", 3, "L", 5
End Sub

Sub D_STOP_WITH_FORM()
CopyLast "AZ", 3, "O", 5
End Sub

Sub TCPA_STOP_WITH_FORM()
CopyLast "AZ", 3, "R", 5
End Sub

Sub TCPB_STOP_WITH_FORM()
CopyLast "AZ", 3, "U", 5
End Sub

Sub TCPC_STOP_WITH_FORM()
CopyLast "AZ", 3, "X", 5
End Sub

Sub LP_STOP_WITH_FORM()
CopyLast "AZ", 3, "L", 19
End Sub

Sub SP_STOP_WITH_FORM()
CopyLast "AZ", 3, "C", 19
End Sub
