Attribute VB_Name = "timesheet2"
Option Explicit

Private Sub CopyLastValue(srcCol As String, srcStartRow As Long, destCol As String, destStartRow As Long)

    Dim ws As Worksheet
    Dim lastSrc As Long
    Dim lastDest As Long
    
    Set ws = Sheets("TIMESHEET")
    
    lastSrc = ws.Cells(ws.Rows.Count, srcCol).End(xlUp).Row
    If lastSrc < srcStartRow Then Exit Sub
    
    lastDest = ws.Cells(ws.Rows.Count, destCol).End(xlUp).Row
    If lastDest < destStartRow Then lastDest = destStartRow - 1
    
    ws.Cells(lastDest + 1, destCol).Value = ws.Cells(lastSrc, srcCol).Value

End Sub


'========================
' COMMON LINE STOP
'========================

Sub CASTOP()
    CopyLastValue "C", 5, "F", 5
End Sub

Sub CBSTOP()
    CopyLastValue "C", 5, "I", 5
End Sub

Sub CCSTOP()
    CopyLastValue "C", 5, "L", 5
End Sub

Sub CDSTOP()
    CopyLastValue "C", 5, "O", 5
End Sub

Sub CTASTOP()
    CopyLastValue "C", 5, "R", 5
End Sub

Sub CTBSTOP()
    CopyLastValue "C", 5, "U", 5
End Sub

Sub CTCSTOP()
    CopyLastValue "C", 5, "X", 5
End Sub


'========================
' COMMON LINE START
'========================

Sub CASTART()
    CopyLastValue "B", 5, "E", 5
End Sub

Sub CBSTART()
    CopyLastValue "B", 5, "H", 5
End Sub

Sub CCSTART()
    CopyLastValue "B", 5, "K", 5
End Sub

Sub CDSTART()
    CopyLastValue "B", 5, "N", 5
End Sub

Sub CTASTART()
    CopyLastValue "B", 5, "Q", 5
End Sub

Sub CTBSTART()
    CopyLastValue "B", 5, "T", 5
End Sub

Sub CTCSTART()
    CopyLastValue "B", 5, "W", 5
End Sub
