VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} NewLogsheet1 
   Caption         =   "NewLogsheet"
   ClientHeight    =   4620
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   6525
   OleObjectBlob   =   "NewLogsheet1.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "NewLogsheet1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub CB_CLOSE_Click()
Unload Me
End Sub

Private Sub CB_SAVE_Click()
'start hour....
'
'
Application.EnableEvents = False
If ComboBox2.Value <> "" Then
   Sheets("LOGSHEET").Range("D56").Value = ComboBox2.Text
    Call PlantSt1
 End If
 
 If ComboBox3.Value <> "" Then
    Sheets("LOGSHEET").Range("D57").Value = ComboBox3.Text
     Call PlantSt2
 End If
 
 If ComboBox4.Value <> "" Then
    Sheets("LOGSHEET").Range("D58").Value = ComboBox4.Text
     Call PlantSt3
End If

If ComboBox3.Value <> "" Then
    Sheets("LOGSHEET").Range("D59").Value = ComboBox3.Text
     Call PlantSt4
End If
'---------------------------------------------------------------
'start min....
'
'
If ComboBox2.Value = "" And ComboBox6.Value <> "" Then
   MsgBox (" Please Enter hour value")
   ComboBox2.SetFocus
Else
    Sheets("LOGSHEET").Range("E56").Value = ComboBox6.Text
End If

If ComboBox3.Value = "" And ComboBox7.Value <> "" Then
   MsgBox (" Please Enter hour value")
   ComboBox3.SetFocus
Else
   Sheets("LOGSHEET").Range("E57").Value = ComboBox7.Text
End If

If ComboBox4.Value = "" And ComboBox8.Value <> "" Then
   MsgBox (" Please Enter hour value")
   ComboBox4.SetFocus
Else
   Sheets("LOGSHEET").Range("E58").Value = ComboBox8.Text
End If

If ComboBox3.Value = "" And ComboBox9.Value <> "" Then
   MsgBox (" Please Enter hour value")
   ComboBox3.SetFocus
Else
   Sheets("LOGSHEET").Range("E59").Value = ComboBox9.Text
End If
'-----------------------------------------------------------
'-----------------------------------------------------------
'stop hour....

If ComboBox17.Value <> "" Then
   Sheets("LOGSHEET").Range("D60").Value = ComboBox17.Text
   Call PlantSp1
End If
If ComboBox16.Value <> "" Then
    Sheets("LOGSHEET").Range("D61").Value = ComboBox16.Text
    Call PlantSp2
End If
If ComboBox15.Value <> "" Then
    Sheets("LOGSHEET").Range("D62").Value = ComboBox15.Text
    Call PlantSp3
End If
If ComboBox14.Value <> "" Then
    Sheets("LOGSHEET").Range("D63").Value = ComboBox14.Text
    Call PlantSp4
End If
'------------------------------------------------------------
'stop min....

If ComboBox17.Value = "" And ComboBox13.Value <> "" Then
   MsgBox (" Please Enter hour value")
   ComboBox17.SetFocus
Else
   Sheets("LOGSHEET").Range("E60").Value = ComboBox13.Text
End If

If ComboBox16.Value = "" And ComboBox12.Value <> "" Then
   MsgBox (" Please Enter hour value")
   ComboBox16.SetFocus
Else
   Sheets("LOGSHEET").Range("E61").Value = ComboBox12.Text
End If


If ComboBox15.Value = "" And ComboBox11.Value <> "" Then
   MsgBox (" Please Enter hour value")
   ComboBox15.SetFocus
Else
   Sheets("LOGSHEET").Range("E62").Value = ComboBox11.Text
End If

If ComboBox14.Value = "" And ComboBox10.Value <> "" Then
   MsgBox (" Please Enter hour value")
   ComboBox10.SetFocus
Else
   Sheets("LOGSHEET").Range("E63").Value = ComboBox10.Text
End If

'Sheets("LOGSHEET").Range("D56:D63").Select
'Application.ScreenUpdating = True
Application.EnableEvents = True
Unload Me
End Sub

Private Sub ComboBox10_Change()
ComboBox10.Value = Format(ComboBox10, "h:mm")
End Sub

Private Sub ComboBox11_Change()
ComboBox11.Value = Format(ComboBox11, "h:mm")
End Sub

Private Sub ComboBox12_Change()
ComboBox12.Value = Format(ComboBox12, "h:mm")
End Sub

Private Sub ComboBox13_Change()
ComboBox13.Value = Format(ComboBox13, "h:mm")
End Sub

Private Sub ComboBox14_Change()
ComboBox14.Value = Format(ComboBox14, "h:mm AM/PM")
ComboBox14.Value = IIf(ComboBox14.Value = "12:25 AM" Or ComboBox14.Value = "1:25 AM", "06:00 ", ComboBox14)
 ComboBox14.Value = IIf(ComboBox14.Value = "12:05 AM" Or ComboBox14.Value = "1:05 AM", "12:00 ", ComboBox14)

End Sub

Private Sub ComboBox15_Change()
ComboBox15.Value = Format(ComboBox15, "h:mm AM/PM")
ComboBox15.Value = IIf(ComboBox15.Value = "12:25 AM" Or ComboBox15.Value = "1:25 AM", "06:00 ", ComboBox15)
 ComboBox15.Value = IIf(ComboBox15.Value = "12:05 AM" Or ComboBox15.Value = "1:05 AM", "12:00 ", ComboBox15)

End Sub

Private Sub ComboBox16_Change()
ComboBox16.Value = Format(ComboBox16, "h:mm AM/PM")
ComboBox16.Value = IIf(ComboBox16.Value = "12:25 AM" Or ComboBox16.Value = "1:25 AM", "06:00 ", ComboBox16)
 ComboBox16.Value = IIf(ComboBox16.Value = "12:05 AM" Or ComboBox16.Value = "1:05 AM", "12:00 ", ComboBox16)

End Sub

Private Sub ComboBox17_Change()
ComboBox17.Value = Format(ComboBox17, "h:mm AM/PM")
ComboBox17.Value = IIf(ComboBox17.Value = "12:25 AM" Or ComboBox17.Value = "1:25 AM", "06:00 ", ComboBox17)
 ComboBox17.Value = IIf(ComboBox17.Value = "12:05 AM" Or ComboBox17.Value = "1:05 AM", "12:00 ", ComboBox17)

End Sub

Private Sub ComboBox2_Change()
ComboBox2.Value = Format(ComboBox2, "h:mm AM/PM")

ComboBox2.Value = IIf(ComboBox2.Value = "12:25 AM" Or ComboBox2.Value = "1:25 AM", "06:00 ", ComboBox2)
 ComboBox2.Value = IIf(ComboBox2.Value = "12:05 AM" Or ComboBox2.Value = "1:05 AM", "12:00 ", ComboBox2)

End Sub

Private Sub ComboBox3_Change()
ComboBox3.Value = Format(ComboBox3, "h:mm AM/PM")
ComboBox3.Value = IIf(ComboBox3.Value = "12:25 AM" Or ComboBox3.Value = "1:25 AM", "06:00 ", ComboBox3)
 ComboBox3.Value = IIf(ComboBox3.Value = "12:05 AM" Or ComboBox3.Value = "1:05 AM", "12:00 ", ComboBox3)

End Sub

Private Sub ComboBox4_Change()
ComboBox4.Value = Format(ComboBox4, "h:mm AM/PM")
ComboBox4.Value = IIf(ComboBox4.Value = "12:25 AM" Or ComboBox4.Value = "1:25 AM", "06:00 ", ComboBox4)
 ComboBox4.Value = IIf(ComboBox4.Value = "12:05 AM" Or ComboBox4.Value = "1:05 AM", "12:00 ", ComboBox4)

End Sub

Private Sub ComboBox5_Change()
ComboBox5.Value = Format(ComboBox5, "h:mm AM/PM")
ComboBox5.Value = IIf(ComboBox5.Value = "12:25 AM" Or ComboBox5.Value = "1:25 AM", "06:00 ", ComboBox5)
 ComboBox5.Value = IIf(ComboBox5.Value = "12:05 AM" Or ComboBox5.Value = "1:05 AM", "12:00 ", ComboBox5)

End Sub



Private Sub ComboBox6_Change()
ComboBox6.Value = Format(ComboBox6, "h:mm")
End Sub

Private Sub ComboBox7_Change()
ComboBox7.Value = Format(ComboBox7, "h:mm")
End Sub

Private Sub ComboBox8_Change()
ComboBox8.Value = Format(ComboBox8, "h:mm")
End Sub

Private Sub ComboBox9_Change()
ComboBox9.Value = Format(ComboBox9, "h:mm")
End Sub




Private Sub UserForm_Initialize()

    

Sheets("LOGSHEET").Activate
'Application.ScreenUpdating = False
End Sub

