Attribute VB_Name = "mGlobals"
Option Explicit

Global g_sDate As String
Global g_bForm As Boolean
