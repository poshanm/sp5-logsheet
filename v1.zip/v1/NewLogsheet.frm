VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} NewLogsheet 
   Caption         =   "NEW LOGSHHET"
   ClientHeight    =   3930
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   3825
   OleObjectBlob   =   "NewLogsheet.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "NewLogsheet"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False





Private Sub ComboBox10_Change()
ComboBox10.Value = Format(ComboBox10, "h:mm")
End Sub

Private Sub ComboBox11_Change()
ComboBox11.Value = Format(ComboBox11, "h:mm")
End Sub

Private Sub ComboBox12_Change()
ComboBox12.Value = Format(ComboBox12, "h:mm")
End Sub

Private Sub ComboBox13_Change()
ComboBox13.Value = Format(ComboBox13, "h:mm")
End Sub

Private Sub ComboBox14_Change()
ComboBox14.Value = Format(ComboBox14, "h:mm AM/PM")
End Sub

Private Sub ComboBox15_Change()
ComboBox15.Value = Format(ComboBox15, "h:mm AM/PM")
End Sub

Private Sub ComboBox16_Change()
ComboBox16.Value = Format(ComboBox16, "h:mm AM/PM")
End Sub

Private Sub ComboBox17_Change()
ComboBox17.Value = Format(ComboBox17, "h:mm AM/PM")
End Sub

Private Sub ComboBox2_Change()
ComboBox2.Value = Format(ComboBox2, "h:mm AM/PM")
End Sub

Private Sub ComboBox3_Change()
ComboBox3.Value = Format(ComboBox3, "h:mm AM/PM")
End Sub

Private Sub ComboBox4_Change()
ComboBox4.Value = Format(ComboBox4, "h:mm AM/PM")
End Sub

Private Sub ComboBox5_Change()
ComboBox4.Value = Format(ComboBox4, "h:mm AM/PM")
End Sub

Private Sub ComboBox6_Change()
ComboBox6.Value = Format(ComboBox6, "h:mm")
End Sub

Private Sub ComboBox7_Change()
ComboBox7.Value = Format(ComboBox7, "h:mm")
End Sub

Private Sub ComboBox8_Change()
ComboBox8.Value = Format(ComboBox8, "h:mm")
End Sub

Private Sub ComboBox9_Change()
ComboBox9.Value = Format(ComboBox9, "h:mm")
End Sub



Private Sub CommandButton1_Click()

Call Datepicker

frmCalendar.Show_Cal
End Sub

Private Sub CommandButton2_Click()
Dim ws As Worksheet
Dim msg1 As String
Dim msg2 As String
 msg1 = Sheets("timesheet").Range("D80").Text
 msg2 = Sheets("timesheet").Range("D81").Text
Set ws = Worksheets("Daily")
Sheets("Daily").Range("T3").Value = ComboBox1.Text
'check for a shift number
If Trim(Me.ComboBox1.Value) = "" Then
  Me.ComboBox1.SetFocus
  MsgBox (msg1)
  Exit Sub
End If
If Trim(Me.TextBox1.Value) = "" Then
  Me.TextBox1.SetFocus
  MsgBox (msg2)
  Exit Sub
End If

Unload Me
End Sub


Private Sub Image1_Click()
Call Datepicker
frmCalendar.Show_Cal
TextBox1.Text = Sheets("Daily").Range("t4").Value
End Sub

Private Sub TextBox1_Change()
TextBox1.Text = Format(Range("T4"), "DD-MMM-YY")
End Sub

Private Sub UserForm_Initialize()
 Call Datepicker
TextBox1.Text = Sheets("Daily").Range("T4").Value

End Sub
Private Sub UserForm_QueryClose(Cancel As Integer, _
  CloseMode As Integer)
  If CloseMode = vbFormControlMenu Then
    Cancel = True
    MsgBox "Please use the SAVE button!"
  End If
End Sub

