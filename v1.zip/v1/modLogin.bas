Attribute VB_Name = "modLogin"
Option Explicit

Public CurrentUserRole As String

Public Sub ShowLogin()
    frmLogin.Show
End Sub


Public Sub LoginAsOperator()

    CurrentUserRole = "Operator"
    
    Sheets("DAILY").Protect "220381", UserInterfaceOnly:=True
    Sheets("LOGSHEET").Protect "220381", UserInterfaceOnly:=True
    
    MsgBox "Logged in as Operator", vbInformation

End Sub


Public Sub LoginAsAdmin()

    CurrentUserRole = "Admin"
    
    Sheets("DAILY").Unprotect "220381"
    Sheets("LOGSHEET").Unprotect "220381"
    
    MsgBox "Logged in as Admin", vbInformation

End Sub
