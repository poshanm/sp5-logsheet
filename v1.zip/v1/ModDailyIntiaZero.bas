Attribute VB_Name = "ModDailyIntiaZero"
Sub DailyInitial_Zero()
Attribute DailyInitial_Zero.VB_ProcData.VB_Invoke_Func = " \n14"
'
' DailyInitial_Zero Macro
'

  With Sheets("DAILY")
        .Range("D5:P5").Value = 0
    End With

End Sub
