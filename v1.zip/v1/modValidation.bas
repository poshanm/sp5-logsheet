Attribute VB_Name = "modValidation"
Public Sub ValidateShift()

    Dim wsL As Worksheet
    Dim wsT As Worksheet
    
    Set wsL = Sheets("LOGSHEET")
    Set wsT = Sheets("TIMESHEET")
    
    wsL.Unprotect "220381"
    
    Dim hasError As Boolean
    hasError = False
    
    ' ===============================
    ' 1?? ROM vs Lines (Main Check)
    ' ===============================
    
    If wsL.Range("I17").Value = _
       wsL.Range("D17").Value + _
       wsL.Range("E17").Value + _
       wsL.Range("F17").Value + _
       wsL.Range("G17").Value + _
       wsL.Range("H17").Value Then
       
        wsL.Range("AE4").Value = "OK"
    Else
        wsL.Range("AE4").Value = "ERROR"
        hasError = True
    End If
    
    
    ' ===============================
    ' 2?? Runtime Check
    ' ===============================
    
    If wsT.Range("AG8").Value <= 480 Then
        wsL.Range("AE5").Value = "OK"
    Else
        wsL.Range("AE5").Value = "ERROR"
        hasError = True
    End If
    
    
    ' ===============================
    ' 3?? Detailed Sheet Validation
    ' ===============================
    
    If DetailedSheetCheck(wsL) Then
        wsL.Range("AE6").Value = "OK"
    Else
        wsL.Range("AE6").Value = "ERROR"
        hasError = True
    End If
    
    wsL.Protect "220381"
    
End Sub

Private Function DetailedSheetCheck(ws As Worksheet) As Boolean

    Dim msgArr(1 To 9) As String
    Dim checkArr(1 To 9) As Boolean
    
    msgArr(1) = ws.Range("K56")
    msgArr(2) = ws.Range("K57")
    msgArr(3) = ws.Range("K58")
    msgArr(4) = ws.Range("K59")
    msgArr(5) = ws.Range("K60")
    msgArr(6) = ws.Range("K61")
    msgArr(7) = ws.Range("K62")
    msgArr(8) = ws.Range("K63")
    msgArr(9) = ws.Range("K64")
    
    checkArr(1) = (Application.Sum(ws.Range("D17:H17")) <> ws.Range("I17"))
    checkArr(2) = (Application.Sum(ws.Range("N17:AA17")) <> ws.Range("I17"))
    checkArr(3) = (Application.Sum(ws.Range("O17,Y17,AA21")) <> ws.Range("T23"))
    checkArr(4) = (Application.Sum(ws.Range("U17,AA17,AA23")) <> ws.Range("T24"))
    checkArr(5) = (Application.Sum(ws.Range("M17,Q17,AA22")) <> ws.Range("T22"))
    checkArr(6) = (Application.Sum(ws.Range("AA21:AA23")) <> ws.Range("AA20"))
    checkArr(7) = (Application.Sum(ws.Range("AA27:AA28")) <> ws.Range("T23"))
    checkArr(8) = (Application.Sum(ws.Range("AA25:AA26")) <> ws.Range("T22"))
    checkArr(9) = (Application.Sum(ws.Range("AA29:AA30,AA24")) <> ws.Range("T24"))
    
    Dim i As Integer
    
    For i = 1 To 9
        If checkArr(i) Then
            MsgBox msgArr(i), vbExclamation
            DetailedSheetCheck = False
            Exit Function
        End If
    Next i
    
    DetailedSheetCheck = True

End Function
