VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} UserForm1 
   Caption         =   "THIS FORM WILL AUTOMATICALLY CLOSE"
   ClientHeight    =   3210
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   6930
   OleObjectBlob   =   "UserForm1.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "UserForm1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Option Explicit





Private Sub Label2_Click()
ThisWorkbook.FollowHyperlink "http://www.NMDC.CO.IN"
End Sub





Private Sub UserForm_Activate()

 Dim i As Long
    
    lblBar.Width = 0
    
    For i = 1 To 100
        lblBar.Width = 2 * i
        DoEvents
        Pause 0.01
    Next i

End Sub

Private Sub UserForm_Initialize()
'lblBar.Caption = Format(Now, "dddd d mmmm yyyy hh:mm:ss")
End Sub
