VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmLogin 
   Caption         =   "UserForm1"
   ClientHeight    =   3015
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   4560
   OleObjectBlob   =   "frmLogin.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmLogin"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit

Private Sub UserForm_Initialize()

    cmbUser.AddItem "Operator"
    cmbUser.AddItem "Admin"
    cmbUser.ListIndex = 0

End Sub

Public Sub ShowLogin()
    frmLogin.Show
End Sub
Private Sub cmdLogin_Click()

    Dim role As String
    Dim pass As String
    
    role = cmbUser.Value
    pass = txtPassword.Value
    
    If role = "Operator" And pass = "1234" Then
        LoginAsOperator
        Me.Hide
        
    ElseIf role = "Admin" And pass = "2203" Then
        LoginAsAdmin
        Me.Hide
        
    Else
        MsgBox "Wrong Password", vbCritical
    End If

End Sub
