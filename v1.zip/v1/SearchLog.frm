VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} SearchLog 
   Caption         =   "Search Logsheet Detail"
   ClientHeight    =   3075
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4050
   OleObjectBlob   =   "SearchLog.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "SearchLog"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub CommandButton1_Click()
Unload Me

End Sub

Private Sub CommandButton2_Click()
Sheets("RECORD").Range("A6") = ComboBox1.Value
Sheets("RECORD").Range("A6:B6").Select
Call combinationFilter

End Sub

Private Sub Image1_Click()
Sheets("RECORD").Activate
Sheets("RECORD").Range("B6").Select
frmCalendar.Show_Cal
End Sub

Private Sub TextBox1_Change()
TextBox1.Text = Format(TextBox1, "dd/mm/yyyy")
End Sub

Private Sub UserForm_Initialize()

Sheets("RECORD").Activate

End Sub
