Attribute VB_Name = "modLoginProtectSave"
Option Explicit

Public CurrentUserRole As String
Public Const APP_PASSWORD As String = "220381"
Public NextSaveTime As Date
'Dim NextSaveTime As Date

'========================
' Save WORKBOOK
'========================

Sub StartAutoSave()

    NextSaveTime = Now + TimeValue("00:05:00")
    Application.OnTime NextSaveTime, "AutoSave"

End Sub


Sub AutoSave()

    On Error Resume Next

    Dim backupPath As String
    backupPath = "E:\Excel_Backup\backup.xlsm"

    'Save main workbook
    ThisWorkbook.Save

    'Create backup copy
    ThisWorkbook.SaveCopyAs backupPath

    'Next run after 5 minutes
    NextSaveTime = Now + TimeValue("00:05:00")
    Application.OnTime NextSaveTime, "AutoSave"

End Sub


'========================
' LOGIN AS OPERATOR
'========================
Public Sub LoginAsOperator()

    CurrentUserRole = "Operator"
    
    ProtectAllSheets
    ProtectWorkbookStructure
    
    MsgBox "Logged in as Operator", vbInformation

End Sub


'========================
' LOGIN AS ADMIN
'========================
Public Sub LoginAsAdmin()

    CurrentUserRole = "Admin"
    
    UnProtectAllSheets
    UnProtectWorkbookStructure
    
    MsgBox "Logged in as Admin", vbInformation

End Sub


'========================
' PROTECT ALL SHEETS
'========================
Public Sub ProtectAllSheets()

    Dim ws As Worksheet
    
    For Each ws In ThisWorkbook.Worksheets
        ws.Protect Password:=APP_PASSWORD, _
                   UserInterfaceOnly:=True
    Next ws

End Sub


'========================
' UNPROTECT ALL SHEETS
'========================
Public Sub UnProtectAllSheets()

    Dim ws As Worksheet
    
    For Each ws In ThisWorkbook.Worksheets
        ws.UnProtect Password:=APP_PASSWORD
    Next ws

End Sub


'========================
' PROTECT WORKBOOK STRUCTURE
'========================
Public Sub ProtectWorkbookStructure()

    ThisWorkbook.Protect Password:=APP_PASSWORD, _
                         Structure:=True, _
                         Windows:=False

End Sub


'========================
' UNPROTECT WORKBOOK
'========================
Public Sub UnProtectWorkbookStructure()

    ThisWorkbook.UnProtect Password:=APP_PASSWORD

End Sub






