Attribute VB_Name = "ModPythonButton"
Dim nextTick As Date
Dim lastRunDate As Double
Dim lastHourRun As Integer

Sub Digital_Clock()

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayStatusBar = False

    On Error Resume Next
    
    With Sheets("DAILY")
        .Range("K3").Value = Format(Now, "hh:mm:ss AM/PM")
    End With


    '--------------------------
    ' DAILY RESET AT MIDNIGHT
    '--------------------------
    If lastRunDate <> Date Then
        lastRunDate = Date
        lastHourRun = -1
    End If


    '--------------------------
    ' PYTHON REPORT 06:05
    '--------------------------
    If Time >= TimeValue("06:05:00") _
        And Time < TimeValue("06:06:00") _
        And lastRunDate <> Date - 0.00001 Then
        
        ThisWorkbook.Save
        Call RunPythonReport
        lastRunDate = Date + 0.00001
        
    End If


    '---------------------------------
    ' RUN led_auto_engine.py EVERY HOUR
    ' AT 15th MINUTE
    '---------------------------------
    If Minute(Now) = 15 And Hour(Now) <> lastHourRun Then
        
        Call RunLedAutoEngine
        lastHourRun = Hour(Now)
        
    End If


    '--------------------------
    ' NEXT LOOP
    '--------------------------
    nextTick = Now + TimeValue("00:00:50")
    Application.OnTime nextTick, "Digital_Clock"


   ' Application.ScreenUpdating = True
   ' Application.EnableEvents = True
   ' Application.DisplayStatusBar = True

End Sub



Sub Digital_Clock1()

    On Error Resume Next
    
    With Sheets("DAILY")
        'Digital clock display
        .Range("K3").Value = Format(Now, "hh:mm:ss AM/PM")
    End With


    '--------------------------
    ' DAILY RESET AT MIDNIGHT
    '--------------------------
    If lastRunDate <> Date Then
        lastRunDate = Date
        lastHourRun = -1
    End If


    '--------------------------
    ' PYTHON REPORT 06:05
    '--------------------------
    If Time >= TimeValue("06:05:00") _
        And Time < TimeValue("06:06:00") _
        And lastRunDate <> Date - 0.00001 Then
        
        ThisWorkbook.Save
        Call RunPythonReport
        lastRunDate = Date + 0.00001
        
    End If


    '---------------------------------
    ' RUN led_auto_engine.py EVERY HOUR
    ' AT 15th MINUTE
    '---------------------------------
    If Minute(Now) = 15 And Hour(Now) <> lastHourRun Then
        
        Call RunLedAutoEngine
        lastHourRun = Hour(Now)
        
    End If


    '--------------------------
    ' LOOP EVERY 45 SEC
    '--------------------------
    nextTick = Now + TimeValue("00:00:45")
    Application.OnTime nextTick, "Digital_Clock"

End Sub


Sub RunLedAutoEngine()
 
 Dim Sh As Object
    Dim result As Long
    
    Set Sh = CreateObject("WScript.Shell")
    
    ' Run Python silently (0 = hidden, True = wait till finish)
    result = Sh.Run("py ""C:\PA_AI\LED\led_update_manual.py""", 0, True)
    
 
 
    
End Sub
Sub RunLedAutoEngine2()

    MsgBox "Starting Python"

    Dim Sh As Object
    Set Sh = CreateObject("WScript.Shell")
    
    Sh.Run "cmd /k py C:\PA_AI\LED\led_update_manual.py"

End Sub


Sub Button1_Click()

   Call RunPythonReport


End Sub

Sub RunPythonReport()

    Dim lastRun As Date
    Dim Sh As Object
    Dim result As Long
    
    'Read last run time from hidden cell
    lastRun = Sheets("DAILY").Range("B3").Value

    'Check 1 minute condition
    If Now - lastRun < TimeValue("00:01:00") Then
        'MsgBox "Wait 1 minute before running again!", vbExclamation, "SP5 System"
        Exit Sub
    End If

    'Save current run time
    Sheets("DAILY").Range("B3").Value = Now

    ThisWorkbook.Save

    Set Sh = CreateObject("WScript.Shell")

    result = Sh.Run("py ""C:\PA_AI\report_sender.py""", 0, True)

    If result = 0 Then
        MsgBox "Production Report Sent Successfully!", vbInformation, "SP5 System"
    Else
        MsgBox "Report Sending Failed! Check Network / Logs.", vbCritical, "SP5 System"
    End If

End Sub

