VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} MenuForm 
   Caption         =   "MENU"
   ClientHeight    =   3510
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   7515
   OleObjectBlob   =   "MenuForm.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "MenuForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub CommandButton2_Click()
Sheets("timesheet").Activate
TimeSheet.Show

End Sub

Private Sub CommandButton3_Click()
Unload Me
Sheets("RECORD").Activate
SearchLog.Show

End Sub

Private Sub CommandButton4_Click()
Sheets("DAILY").Activate
End Sub

Private Sub CommandButton5_Click()
NewLogsheet.Show
    NewLogsheet1.Show
End Sub

Private Sub CommandButton6_Click()
 Call MakeFoderCopy
 'Call SaveAsPDF
End Sub

Private Sub CommandButton7_Click()
Unload Me
End Sub

Private Sub CommandButton8_Click()
LanguageOption.Show
End Sub

Private Sub CreatNewLog_Click()
Call CreatNewLog1

End Sub



Private Sub Label1_Click()

End Sub

