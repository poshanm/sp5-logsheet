Attribute VB_Name = "CalendarDatePicker"
Option Explicit
Private Const SHORTCUT_KEY As String = "^+d"

Private Sub Auto_Open()
    On Error Resume Next
    Application.OnKey SHORTCUT_KEY, "CalendarDatePicker.ShowCalendarPicker"
End Sub

Private Sub Auto_Close()
    On Error Resume Next
    Application.OnKey SHORTCUT_KEY
End Sub

Public Sub ShowCalendarPicker()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    If Selection.Count <> 1 Then Exit Sub
    Dim cellRef As Range
    Set cellRef = Selection
    Dim defaultDate As Date
    If IsDate(cellRef.Value) Then
        defaultDate = cellRef.Value
    Else
        defaultDate = Date
    End If
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    UserForm1.ShowCalendar defaultDate, cellRef
    Application.ScreenUpdating = True
    Application.EnableEvents = True
End Sub

Public Sub OnDatePickerButton(control As IRibbonControl)
    ShowCalendarPicker
End Sub

