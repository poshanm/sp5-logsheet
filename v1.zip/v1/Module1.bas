Attribute VB_Name = "Module1"
Option Explicit

Sub EndSplash()
Unload UserForm1
End Sub

 
Public Sub Pause(ByVal seconds As Double)

    Dim endTime As Double
    endTime = Timer + seconds
    
    Do While Timer < endTime
        DoEvents
    Loop

End Sub
