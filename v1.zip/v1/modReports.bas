Attribute VB_Name = "modReports"
Public Function GetReportPath() As String

    Dim basePath As String
    Dim yearPath As String
    Dim monthPath As String
    
    basePath = ThisWorkbook.Path & "\Reports"
    yearPath = basePath & "\" & Year(Date)
    monthPath = yearPath & "\" & Format(Date, "mmmm")
    
    If Dir(basePath, vbDirectory) = "" Then MkDir basePath
    If Dir(yearPath, vbDirectory) = "" Then MkDir yearPath
    If Dir(monthPath, vbDirectory) = "" Then MkDir monthPath
    
    GetReportPath = monthPath

End Function


Public Sub GenerateShiftPDF()

    Dim ws As Worksheet
    Set ws = Sheets("LOGSHEET")
    
    Dim reportPath As String
    reportPath = GetReportPath()
    
    Dim fileName As String
    fileName = "Shift_" & _
               Sheets("DAILY").Range("S4").Value & "_" & _
               Sheets("DAILY").Range("T3").Value & ".pdf"
    
    ws.ExportAsFixedFormat _
        Type:=xlTypePDF, _
        fileName:=reportPath & "\" & fileName

End Sub

