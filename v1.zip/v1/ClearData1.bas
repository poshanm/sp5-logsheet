Attribute VB_Name = "ClearData1"
Public Sub ClearData()
'
' ClearData Macro
'

'
' 1?? Confirm
Dim msg1 As String
 msg1 = Sheets("timesheet").Range("D84").Text
rspn = MsgBox(msg1, vbYesNo)
If rspn = vbNo Then Exit Sub



    ' 2?? Save
ThisWorkbook.Save

Application.ScreenUpdating = False
Application.EnableEvents = False


Call wbUnProtect
Call UnProtect

' 3?? Backup
Call MakeFoderCopy
'Call record
Call SaveAsPDF
  
  ' 4?? Shift Calc
 Call Shift_cum
 Sheets("LOGSHEET").Activate
       Call CopyPrevR
       
       '' 6?? Clear Logsheet ST/SP
     Call ClearStSp
     
      ' 7?? Clear Daily
    Sheets("DAILY").Activate
    Call UnProtect
    Range("D7:P14").Select
    Selection.ClearContents
   ' Range("D5:I5").Select
    'Selection.ClearContents
   Range("T3:T4").Select
    Selection.ClearContents
   
    Range("U7:U15").Select
    Selection.ClearContents
    
    ' 8?? Reset Initial
     Call DailyInitial_Zero
     
     ' 9?? Clear Timesheet
    Call clear_timesheet1
    
    Sheets("DAILY").Activate
    ' ? NOW OPEN FORM (LAST STEP ONLY)
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    
    NewLogsheet.Show

    
  '  Sheets("LOGSHEET").Activate
   ' ?? Monthly Reset
     If Sheets("logsheet").Range("H58").Value = "TRUE" Then
       Call CLEAR_STOPPAGE
    End If
    
      If Sheets("logsheet").Range("H56").Value = "TRUE" Then
       Call Date1Reset
      ' Call CopyIntial
    End If
    
    If Sheets("logsheet").Range("H57").Value = "TRUE" Then
    Sheets("LOGSHEET").Activate
       Range("Q26:Q31").Select
    Selection.ClearContents
  
     End If
     
    Sheets("DAILY").Activate
    Call wbProtect
    Call Protect
    Application.EnableEvents = True
    Application.ScreenUpdating = True
End Sub
Public Sub ClearData_1()

    On Error GoTo SafeExit
    
    Dim wsL As Worksheet
    Dim wsD As Worksheet
    Dim wsT As Worksheet
    Dim msgText As String
    Dim cmd As String
    
    Set wsL = Sheets("LOGSHEET")
    Set wsD = Sheets("DAILY")
    Set wsT = Sheets("TIMESHEET")
    
    ' 1?? Confirm
    With Sheets("Daily")

    If .Range("T3").Value = "3rd" And .Range("K3").Value < TimeValue("06:10:00") Then
        MsgBox "Please try after 6:10 AM", vbExclamation
        Exit Sub
    End If

    End With

     msgText = wsT.Range("D84").Value
     If MsgBox(msgText, vbYesNo + vbQuestion, "Confirm Shift Close") = vbNo Then Exit Sub
    
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    
    ' 2?? Save
    ThisWorkbook.Save
    
    ' 3?? Backup
    MakeFoderCopy
    SaveAsPDF
    
    ' 4?? Shift Calc
    Shift_cum
    CopyPrevR
    
    ' 5?? Python only 1st shift
    'If wsD.Range("T3").Value = "1st" Then
     '   cmd = "cmd /c cd C:\PA_AI && python report_sender.py"
      '  Shell cmd, vbNormalFocus
    'End If
    
    ' 6?? Clear Logsheet ST/SP
    ClearStSp
    
    ' 7?? Clear Daily
    wsD.Range("D7:L14").ClearContents
    wsD.Range("T3:T4").ClearContents
    wsD.Range("U7:U15").ClearContents
    
    ' 8?? Reset Initial
    DailyInitial_Zero
    
    ' 9?? Clear Timesheet
    clear_timesheet1
    
     ' ? NOW OPEN FORM (LAST STEP ONLY)
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    
    NewLogsheet.Show
    ' ?? Monthly Reset
    If wsL.Range("H56").Value = "TRUE" Then Date1Reset
    If wsL.Range("H57").Value = "TRUE" Then wsL.Range("Q26:Q31").ClearContents
    
   

    Exit Sub

SafeExit:
    Application.EnableEvents = True
    Application.ScreenUpdating = True

End Sub
