Attribute VB_Name = "modShiftSystem"
Option Explicit

' ===============================
' ?? MAIN ENTRY POINT
' ===============================
Public Sub ClearData()

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    
    Dim cmd As String
    Dim response As VbMsgBoxResult
    
    ' Ask confirmation first
    response = MsgBox(Sheets("TIMESHEET").Range("D84").Text, vbYesNo + vbQuestion, "Confirm Report")
    
    If response = vbNo Then Exit Sub
    
    ' Save workbook properly (no SendKeys nonsense)
    ThisWorkbook.Save
    
    ' Build command
    'cmd = "cmd /c cd /d C:\PA_AI && python report_sender.py"
    
    ' Run hidden (better than vbNormalFocus)
    'Shell cmd, vbHide
    
    If Not BasicChecks Then GoTo ExitHandler
    If Not ValidationCheck Then GoTo ExitHandler

    SaveShiftToHistory
    GenerateShiftPDF
    CreateShiftBackup
    
    ProcessShiftCalculations
    CopyPreviousReadingsIfRequired
    ClearStoppageIfRequired
    
    CopyFinalToInitial
    ClearDailyEntryArea
    ResetRuntime
    ClearTimesheetData
    'ResetDateIfRequired
    
    NewLogsheet.Show
    
    MsgBox "Shift Closed Successfully.", vbInformation

ExitHandler:
    Application.EnableEvents = True
    Application.ScreenUpdating = True

End Sub

Private Function BasicChecks() As Boolean

    If Sheets("DAILY").Range("T3") = "" Then
        MsgBox "Please Select Shift."
        Exit Function
    End If
    
    If Sheets("DAILY").Range("T4") = "" Then
        MsgBox "Please Select Date."
        Exit Function
    End If
    
    If Sheets("LOGSHEET").Range("H17") = 0 Then
        MsgBox "No Production Data Found."
        Exit Function
    End If
    
    BasicChecks = True

End Function
Private Function ValidationCheck() As Boolean

    ValidateShift
    
    With Sheets("LOGSHEET")
        If .Range("AD4") = "ERROR" _
        Or .Range("AD5") = "ERROR" _
        Or .Range("AD6") = "ERROR" Then
        
            MsgBox "Validation Failed."
            Exit Function
        End If
    End With
    
    ValidationCheck = True

End Function

Private Sub ProcessShiftCalculations()

    If Sheets("DAILY").Range("T4") <> Date Then
        UpdatePreviousDay
    End If
    
    Select Case Sheets("DAILY").Range("T3")
        Case "1st": ApplyShift1
        Case "2nd": ApplyShift2
        Case "3rd": ApplyShift3
    End Select

End Sub
Private Sub ApplyShift1()
    Sheets("DAILY").Range("I27:I32").Value = Sheets("DAILY").Range("J35:J40").Value
End Sub

Private Sub ApplyShift2()
    Sheets("DAILY").Range("J27:J32").Value = Sheets("DAILY").Range("K35:K40").Value
End Sub

Private Sub ApplyShift3()
    Sheets("DAILY").Range("K27:K32").Value = Sheets("DAILY").Range("L35:L40").Value
End Sub
Private Sub UpdatePreviousDay()

    With Sheets("DAILY")
        .Range("N26").Value = .Range("T4").Value
        .Range("P27:R32").Value = .Range("J19:L24").Value
        .Range("T27:U32").Value = .Range("M19:N24").Value
        .Range("U27:V32").Value = .Range("O19:P24").Value
    End With

End Sub
Private Sub CopyPreviousReadingsIfRequired()

    If Sheets("LOGSHEET").Range("H56") = "FALSE" Then
    
        With Sheets("LOGSHEET")
            .Range("Q25:Q31").Value = .Range("T25:T31").Value
            .Range("Q21").Value = .Range("T21").Value
            .Range("X21:X24").Value = .Range("AA21:AA24").Value
            .Range("X26").Value = .Range("AA26").Value
            .Range("X28").Value = .Range("AA28").Value
            .Range("X30").Value = .Range("AA30").Value
            .Range("D15:AB15").Value = .Range("D17:AB17").Value
        End With
        
    End If

End Sub
Private Sub ClearStoppageIfRequired()

    If Sheets("LOGSHEET").Range("H57") = "TRUE" Then
    
        Sheets("LOGSHEET").Range("M2:N3,Q2:R3,T2:U3,X2:Y3").ClearContents
        
    End If

End Sub
Private Sub CopyFinalToInitial()

    With Sheets("DAILY")
        .Range("D4:H4").Value = Sheets("LOGSHEET").Range("C16:G16").Value
    End With

End Sub
Private Sub ClearDailyEntryArea()

    With Sheets("DAILY")
        .Range("D7:Q14").ClearContents
        .Range("T3:T4").ClearContents
        .Range("U7:U15").ClearContents
    End With

End Sub
Private Sub ResetRuntime()

    Dim i As Long
    
    With Sheets("TIMESHEET")
        For i = 3 To 9
            .Cells(i, "AE") = "STOPPED"
            .Cells(i, "AF").ClearContents
            .Cells(i, "AG") = 0
        Next i
    End With

End Sub
Private Sub ClearTimesheetData()

    Sheets("TIMESHEET").Range( _
    "B7:C17,E7:F17,H7:I17,K7:L17,N7:O17,Q7:R17,T7:U17,W7:X17,B21:C31,E21:I31,K21:L31,N21:R31").ClearContents

End Sub

