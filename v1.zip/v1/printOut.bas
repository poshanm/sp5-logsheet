Attribute VB_Name = "printOut"
Sub printlog()
Attribute printlog.VB_ProcData.VB_Invoke_Func = " \n14"
'
' PRINTLOG Macro
'

'


    Range("C1:AB30").Select
    Application.WindowState = xlMinimized
    Application.WindowState = xlMinimized
    Selection.printOut Copies:=1, Collate:=True, IgnorePrintAreas:=False


    ActiveWorkbook.SaveAs Filename:="C:\SP\" & Sheets("LOGSHEET").Range("H61").Text & ".xlsm" _
        , FileFormat:=xlOpenXMLWorkbookMacroEnabled, CreateBackup:=False
    ActiveWindow.Close
End Sub
