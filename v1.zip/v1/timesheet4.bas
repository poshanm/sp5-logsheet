Attribute VB_Name = "timesheet4"
Option Explicit

Private Sub CopyLast(srcCol As String, srcStartRow As Long, destCol As String, destStartRow As Long)

    Dim ws As Worksheet
    Dim lastSrc As Long
    Dim lastDest As Long
    
    Set ws = Sheets("TIMESHEET")
    
    lastSrc = ws.Cells(ws.Rows.Count, srcCol).End(xlUp).Row
    If lastSrc < srcStartRow Then Exit Sub
    
    lastDest = ws.Cells(ws.Rows.Count, destCol).End(xlUp).Row
    If lastDest < destStartRow Then lastDest = destStartRow - 1
    
    ws.Cells(lastDest + 1, destCol).Value = ws.Cells(lastSrc, srcCol).Value

End Sub


'========================
' SP STOPPAGE LOGIC
'========================

Sub SPS_WITH_RUNNING_SP()

    ' K column last ? C column
    CopyLast "K", 19, "C", 5

End Sub


Sub SPS_WITH_CONT_LP()

    ' K column last ? C column (LP section)
    CopyLast "K", 19, "C", 19

End Sub


Sub LPS_WITH_RUNNING_SP()

    ' B column last ? C column
    CopyLast "B", 19, "C", 5

End Sub


Sub LPS_WITH_CONT_SP()

    ' B column last ? L column
    CopyLast "B", 19, "L", 19

End Sub
