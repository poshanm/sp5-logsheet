Attribute VB_Name = "protectUn"

Sub Protect()
'
' protect Macro
'

'
   Sheets("LOGSHEET").Protect "220381"
   Sheets("DAILY").Protect "220381"
   Sheets("timesheet").Protect "220381"
    
End Sub
 Sub UnProtect()
'
' Unprotect Macro
'

'

   Sheets("LOGSHEET").UnProtect "220381"
   Sheets("DAILY").UnProtect "220381"
   Sheets("timesheet").UnProtect "220381"
    
 End Sub

Sub wbProtect()
ActiveWorkbook.Protect Password:="220381", Structure:=True, Windows:=True
End Sub
Sub wbUnProtect()
ActiveWorkbook.UnProtect Password:="220381"

End Sub

