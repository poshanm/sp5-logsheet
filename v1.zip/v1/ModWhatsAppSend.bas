Attribute VB_Name = "ModWhatsAppSend"



Sub Clear_Record()
Attribute Clear_Record.VB_ProcData.VB_Invoke_Func = " \n14"
'
' Clear_Record Macro
'

'
    'msg1 = Sheets("timesheet").Range("D84").Text
    msg1 = "Kya aap is sheet ki Stoppage ki timing Clear karana Chah rahe hain ?"
rspn = MsgBox(msg1, vbYesNo)
If rspn = vbNo Then Exit Sub

Sheet13.UnProtect "220381"
   ' Range("C12:E12").Select
   ' Selection.ClearContents
    
    Range("C16:D16").Select
    Selection.ClearContents
    
    Range("C17:P17").Select
    Selection.ClearContents
    
    Range("C21:D21").Select
    Selection.ClearContents
    
    Range("C22:P22").Select
    Selection.ClearContents
    
    Range("C26:D26").Select
    Selection.ClearContents
    
    Range("C27:P27").Select
    Selection.ClearContents
    
   
    
    Sheet13.Protect "220381"
    
    
    
End Sub
Sub Copy_As_text_for_Whasapp()
Attribute Copy_As_text_for_Whasapp.VB_ProcData.VB_Invoke_Func = " \n14"
'
' Copy_As_text_for_Whasapp Macro
'

'
    
    Range("s4:s46").Select
    Selection.Copy
End Sub
 

Sub wpp()

Dim IE As Object
Dim mymesssage As String
Dim mynumber As String
Dim rownum As Long
    
rownum = 2
    
Do Until Cells(rownum, 1) = ""
    Cells(rownum, 1) = mymessage
    Cells(rownum, 2) = mynumber
    
    Set IE = CreateObject("InternetExplorer.Application")
    IE.Navigate "whatsapp://send?phone=" & mynumber & "&text=" & mymessage
    Application.Wait Now() + TimeSerial(0, 0, 3)
    SendKeys "~"
    Set IE = Nothing
    
    rownum = rownum + 1
Loop
    
End Sub



Sub Send_WhatsApp()

Dim whatsapp_number As String


Dim Sh As Worksheet
'Set sh = ThisWorkbook.Sheets("Sheet13")
Set Sh = ThisWorkbook.Sheets("REPORT")

Dim i As Integer
Dim strMessage As String

'strMessage = LblCompany.Text & "%0a" & "Invoice Number : " & txtInvoiceno.Text & "%0a" & "Invoice Date : " & DtInvdate.Value.ToString("MM/dd/yyyy") & ""
 
strMessage = Sheets("REPORT").Range("S4").Text & "%0a" & Sheets("REPORT").Range("S5").Text & "%0a" & Sheets("REPORT").Range("S6").Text & "%0a" & Sheets("REPORT").Range("S7").Text _
& "%0a" & Sheets("REPORT").Range("S8").Text & "%0a" & Sheets("REPORT").Range("S9").Text & "%0a" & Sheets("REPORT").Range("S10").Text & "%0a" & Sheets("REPORT").Range("S11").Text _
& "%0a" & Sheets("REPORT").Range("S12").Text & "%0a" & Sheets("REPORT").Range("S13").Text & "%0a" & Sheets("REPORT").Range("S14").Text & "%0a" & Sheets("REPORT").Range("S15").Text _
& "%0a" & Sheets("REPORT").Range("S16").Text & "%0a" & Sheets("REPORT").Range("S17").Text & "%0a" & Sheets("REPORT").Range("S18").Text & "%0a" & Sheets("REPORT").Range("S19").Text _
& "%0a" & Sheets("REPORT").Range("S20").Text & "%0a" & Sheets("REPORT").Range("S21").Text & "%0a" & Sheets("REPORT").Range("S22").Text & "%0a" & Sheets("REPORT").Range("S23").Text _
& "%0a" & Sheets("REPORT").Range("S24").Text & "%0a" & Sheets("REPORT").Range("S25").Text & "%0a" & Sheets("REPORT").Range("S26").Text & "%0a" & Sheets("REPORT").Range("S27").Text _
& "%0a" & Sheets("REPORT").Range("S28").Text & "%0a" & Sheets("REPORT").Range("S29").Text & "%0a" & Sheets("REPORT").Range("S30").Text & "%0a" & Sheets("REPORT").Range("S31").Text _
& "%0a" & Sheets("REPORT").Range("S32").Text & "%0a" & Sheets("REPORT").Range("S33").Text & "%0a" & Sheets("REPORT").Range("S34").Text & "%0a" & Sheets("REPORT").Range("S35").Text _
& "%0a" & Sheets("REPORT").Range("S36").Text & "%0a" & Sheets("REPORT").Range("S37").Text & "%0a" & Sheets("REPORT").Range("S38").Text & "%0a" & Sheets("REPORT").Range("S39").Text _
& "%0a" & Sheets("REPORT").Range("S40").Text & "%0a" & Sheets("REPORT").Range("S41").Text & "%0a" & Sheets("REPORT").Range("S42").Text & "%0a" & Sheets("REPORT").Range("S43").Text _
& "%0a" & Sheets("REPORT").Range("S44").Text & "%0a" & Sheets("REPORT").Range("S45").Text & "%0a" & Sheets("REPORT").Range("S46").Text & "%0a" & Sheets("REPORT").Range("S47").Text

For i = 2 To Sh.Range("T" & Application.Rows.Count).End(xlUp).Row

If Sh.Range("V" & i).Value <> "Yes" Then   '' Check Skip

        whatsapp_number = Sh.Range("U" & i).Value
    
       ' ThisWorkbook.FollowHyperlink "https://web.whatsapp.com/send?phone=%2B" & whatsapp_number & "&text=" & _
       ' sh.Range("K" & i).Value & "&app_absent=1&send=1"
       ThisWorkbook.FollowHyperlink "https://web.whatsapp.com/send?phone=%2B" & whatsapp_number & "&text=" & strMessage & "&app_absent=1&send=1"
      
            Application.Wait (Now() + TimeValue("00:00:20"))

            VBA.SendKeys "~", True
            
            Application.Wait (Now() + TimeValue("00:00:01"))
            
             
    End If

Next i

MsgBox "Process Completed", vbInformation

End Sub

'Sub Digital_clock()
'Worksheets("DAILY").Range("K3").Value = Now
'Application.OnTime Now + TimeValue("00:00:01"), "Digital_clock"

'End Sub

