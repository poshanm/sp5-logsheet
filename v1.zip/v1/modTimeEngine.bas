Attribute VB_Name = "modTimeEngine"

Public Function GetShiftStartTime(shiftName As String, shiftDate As Date) As Date

    Select Case shiftName
        Case "1st"
            GetShiftStartTime = shiftDate + TimeValue("06:00:00")
        Case "2nd"
            GetShiftStartTime = shiftDate + TimeValue("14:00:00")
        Case "3rd"
            GetShiftStartTime = shiftDate + TimeValue("22:00:00")
    End Select

End Function


Public Function GetShiftEndTime(shiftName As String, shiftDate As Date) As Date

    Select Case shiftName
        Case "1st"
            GetShiftEndTime = shiftDate + TimeValue("14:00:00")
        Case "2nd"
            GetShiftEndTime = shiftDate + TimeValue("22:00:00")
        Case "3rd"
            GetShiftEndTime = shiftDate + 1 + TimeValue("06:00:00")
    End Select

End Function
Public Function GetLineRow(lineName As String) As Long

    Dim ws As Worksheet
    Set ws = Sheets("TIMESHEET")
    
    Dim i As Long
    
    For i = 3 To 9   'because now A,B,C,D,E,SP,LP
        If ws.Cells(i, "AD").Value = lineName Then
            GetLineRow = i
            Exit Function
        End If
    Next i

End Function
Public Sub StartLine(lineName As String)

    Dim ws As Worksheet
    Set ws = Sheets("TIMESHEET")
    
    Dim rowNum As Long
    rowNum = GetLineRow(lineName)
    
    If ws.Cells(rowNum, "AE").Value = "RUNNING" Then Exit Sub
    
    ws.Cells(rowNum, "AE").Value = "RUNNING"
    ws.Cells(rowNum, "AF").Value = Now

End Sub
Public Sub StopLine(lineName As String)

    Dim ws As Worksheet
    Set ws = Sheets("TIMESHEET")
    
    Dim rowNum As Long
    rowNum = GetLineRow(lineName)
    
    If ws.Cells(rowNum, "AE").Value <> "RUNNING" Then Exit Sub
    
    Dim startTime As Date
    startTime = ws.Cells(rowNum, "AF").Value
    
    Dim minutesRun As Double
    minutesRun = DateDiff("n", startTime, Now)
    
    ws.Cells(rowNum, "AG").Value = _
        ws.Cells(rowNum, "AG").Value + minutesRun
    
    ws.Cells(rowNum, "AE").Value = "STOPPED"

End Sub
Public Sub HandleStartEvent()

    Dim eventType As String
    eventType = Sheets("TIMESHEET").Range("AU6").Value
    
    Select Case eventType
    
        Case "A LINE START": StartLine "A"
        Case "B LINE START": StartLine "B"
        Case "C LINE START": StartLine "C"
        Case "D LINE START": StartLine "D"
        Case "SP START": StartLine "SP"
        Case "LP START": StartLine "LP"
        
    End Select

End Sub


Public Sub HandleStopEvent()

    Dim eventType As String
    eventType = Sheets("TIMESHEET").Range("AW6").Value
    
    Select Case eventType
    
        Case "A LINE STOP": StopLine "A"
        Case "B LINE STOP": StopLine "B"
        Case "C LINE STOP": StopLine "C"
        Case "D LINE STOP": StopLine "D"
        Case "SP STOP": StopLine "SP"
        Case "LP STOP": StopLine "LP"
        
    End Select

End Sub

