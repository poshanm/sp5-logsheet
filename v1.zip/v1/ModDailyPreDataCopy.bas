Attribute VB_Name = "ModDailyPreDataCopy"

Public Sub PRE_DAY()

    Dim wsD As Worksheet
    Dim wsL As Worksheet
    
    Set wsD = Sheets("DAILY")
    Set wsL = Sheets("DAILY")
    
    ' Date copy (T4 ? M27)
    wsL.Range("M27").Value = wsD.Range("T4").Value
    
    ' Production blocks copy
    wsL.Range("O28:Q34").Value = wsD.Range("I19:K25").Value
    wsL.Range("S28:T34").Value = wsD.Range("L19:M25").Value
    wsL.Range("T28:U34").Value = wsD.Range("N19:O25").Value

End Sub
Sub Macro4()

With Sheets("DAILY")
        .Range("M27").ClearContents
        .Range("O28:T34").ClearContents
    End With
    
End Sub

