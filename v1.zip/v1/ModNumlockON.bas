Attribute VB_Name = "ModNumlockON"
#If VBA7 Then
    Private Declare PtrSafe Function GetKeyState Lib "user32" (ByVal nVirtKey As Long) As Integer
    Private Declare PtrSafe Sub keybd_event Lib "user32" (ByVal bVk As Byte, ByVal bScan As Byte, ByVal dwFlags As Long, ByVal dwExtraInfo As Long)
#Else
    Private Declare Function GetKeyState Lib "user32" (ByVal nVirtKey As Long) As Integer
    Private Declare Sub keybd_event Lib "user32" (ByVal bVk As Byte, ByVal bScan As Byte, ByVal dwFlags As Long, ByVal dwExtraInfo As Long)
#End If

Const VK_NUMLOCK As Long = &H90
Const KEYEVENTF_EXTENDEDKEY As Long = &H1
Const KEYEVENTF_KEYUP As Long = &H2


Sub EnsureNumLockOn()

    If (GetKeyState(VK_NUMLOCK) And 1) = 0 Then
    
        Application.ScreenUpdating = False
        
        keybd_event VK_NUMLOCK, &H45, KEYEVENTF_EXTENDEDKEY, 0
        keybd_event VK_NUMLOCK, &H45, KEYEVENTF_EXTENDEDKEY Or KEYEVENTF_KEYUP, 0
        
        Application.ScreenUpdating = True
        
    End If

End Sub
